#pragma once

#include "nsbxgi.h"
#include "Type/Vector/Vec3f.h"

struct bxgi::TVertex : public bxcf::Vec3f
{
};