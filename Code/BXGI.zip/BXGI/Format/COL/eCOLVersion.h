#pragma once

#include "nsbxgi.h"
#include "Type/Types.h"

enum bxgi::ECOLVersion
{
	COL_UNKNOWN		= 0,
	COL_1			= 1,
	COL_2			= 2,
	COL_3			= 3,
	COL_4			= 4
};