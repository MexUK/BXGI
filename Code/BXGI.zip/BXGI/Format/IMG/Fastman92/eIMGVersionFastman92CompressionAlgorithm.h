#pragma once

#include "nsbxgi.h"

enum bxgi::EIMGVersionFastman92CompressionAlgorithm // todo - rename other enum with algoruthm in it to not have Id at the end
{
	IMGFASTMAN92COMPRESSIONALGORITHM_UNKNOWN,
	IMGFASTMAN92COMPRESSIONALGORITHM_UNCOMPRESSED,
	IMGFASTMAN92COMPRESSIONALGORITHzLIB,
	IMGFASTMAN92COMPRESSIONALGORITHM_LZ4,
};