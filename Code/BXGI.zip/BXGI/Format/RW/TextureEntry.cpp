#include "TextureEntry.h"

using namespace bxgi;

TextureEntry::TextureEntry(void) :
	m_bHasDiffuse(false),
	m_bHasAlpha(false),
	m_pRWTextureSection(nullptr)
{
}