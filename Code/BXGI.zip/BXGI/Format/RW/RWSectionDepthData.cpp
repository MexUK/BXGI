#include "RWSectionDepthData.h"

using namespace bxgi;

RWSectionDepthData::RWSectionDepthData(void) :
	m_uiSectionId(0),
	m_uiSectionSize(0),
	m_uiSectionByteCountRead(0)
{
}