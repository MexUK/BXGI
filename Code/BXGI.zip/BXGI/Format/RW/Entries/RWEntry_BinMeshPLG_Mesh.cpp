#include "RWEntry_BinMeshPLG_Mesh.h"

using namespace bxgi;

RWEntry_BinMeshPLG_Mesh::RWEntry_BinMeshPLG_Mesh(void) :
	m_uiIndexCount(0),
	m_uiMaterialIndex(0)
{
}