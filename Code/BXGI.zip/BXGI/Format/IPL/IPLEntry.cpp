#include "Format/IPL/IPLEntry.h"

using namespace std;
using namespace bxgi;

IPLEntry::IPLEntry(IPLFormat *pIPLFormat) :
	SectionLinesEntry(pIPLFormat)
{
}