#pragma once

#include "nsbxgi.h"

#pragma pack(push, 1)
struct bxgi::DATEntry_Paths_Default_LinkLength
{
	uint8			m_ucLength;
};
#pragma pack(pop)