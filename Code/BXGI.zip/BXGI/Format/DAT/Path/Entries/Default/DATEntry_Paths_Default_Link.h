#pragma once

#include "nsbxgi.h"

#pragma pack(push, 1)
struct bxgi::DATEntry_Paths_Default_Link
{
	uint16			m_usAreaId;
	uint16			m_usNodeId;
};
#pragma pack(pop)