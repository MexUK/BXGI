#pragma once

#include "nsbxgi.h"

class bxgi::CompressedVector_extended
{
public:
	signed __int32 x;
	signed __int32 y;
	signed __int32 z;
};