#pragma once

#include "nsbxgi.h"

struct bxgi::DATEntry_Paths_Fastman92_Link
{
	uint16			m_usAreaId;
	uint16			m_usNodeId;
};