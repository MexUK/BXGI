#pragma once

#include "nsbxgi.h"

struct bxgi::NodeAddress
{
	unsigned __int16 areaId;
	unsigned __int16 nodeId;
};