#pragma once

#include "nsbxgi.h"

struct bxgi::DATEntry_Paths_Fastman92_PathIntersectionFlags
{
	uint8			m_ucData;
};