#pragma once

#include "nsbxgi.h"
#include "Format/DAT/Path/Entries/Fastman92/DATEntry_Paths_Fastman92_NaviNode.h"

struct bxgi::DATEntry_Paths_Fastman92_NaviNode_extended : public DATEntry_Paths_Fastman92_NaviNode
{
	signed __int32 extended_posX;
	signed __int32 extended_posY;
};