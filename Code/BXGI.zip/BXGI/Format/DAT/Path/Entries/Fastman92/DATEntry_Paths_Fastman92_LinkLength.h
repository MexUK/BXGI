#pragma once

#include "nsbxgi.h"

struct bxgi::DATEntry_Paths_Fastman92_LinkLength
{
	uint8			m_ucLength;
};