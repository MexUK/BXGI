#pragma once

#include "nsbxgi.h"

struct bxgi::DATEntry_Paths_Fastman92_NaviLink
{
	uint32			m_uiData; // lower 16 bit are the Navi Node ID, upper 16 bit the corresponding Area ID
};