#pragma once

#include "nsbxgi.h"

class bxgi::CompressedVector
{
public:
	signed __int16 x;
	signed __int16 y;
	signed __int16 z;
};