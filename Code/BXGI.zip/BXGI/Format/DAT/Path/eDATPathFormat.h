#pragma once

#include "nsbxgi.h"
#include "Type/Types.h"

enum bxgi::EDATPathFormat
{
	DAT_PATH_UNKNOWN,
	DAT_PATH_DEFAULT,
	DAT_PATH_FASTMAN92
};