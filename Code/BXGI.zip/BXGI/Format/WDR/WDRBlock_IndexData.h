#pragma once

#include "nsbxgi.h"

class bxgi::WDRBlock_IndexData
{
public:
	uint16				m_usVertexIndices[3];
};