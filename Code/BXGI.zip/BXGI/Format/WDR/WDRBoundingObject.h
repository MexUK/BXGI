#pragma once

#include "nsbxgi.h"

class bxgi::WDRBoundingObject
{
public:
	float32					m_fMin[4]; // x y z w
	float32					m_fMax[4]; // x y z w
};