#pragma once

#include "nsbxgi.h"
#include "Type/Types.h"

enum bxgi::EIDEPathType
{
	IDE_PATH_UNKNOWN,
	IDE_PATH_GROUP,
	IDE_PATH_NODE
};