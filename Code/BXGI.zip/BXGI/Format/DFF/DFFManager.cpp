#include "DFFManager.h"

using namespace std;
using namespace bxgi;

DFFManager::DFFManager(void)
{
}

void				DFFManager::init(void)
{
}
void				DFFManager::uninit(void)
{
}