#include "PlatformedGame.h"
#include "nsbxgi.h"

using namespace bxgi;

PlatformedGame::PlatformedGame(void) :
	m_uiPlatformedGameId(UNKNOWN_PLATFORMED_GAME)
{
}