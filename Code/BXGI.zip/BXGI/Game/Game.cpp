#include "Game.h"
#include "nsbxgi.h"

using namespace bxgi;

Game::Game(void) :
	m_uiGameId(UNKNOWN_GAME)
{
}