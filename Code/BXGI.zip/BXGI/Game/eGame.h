#pragma once

#include "nsbxgi.h"
#include "Type/Types.h"

enum bxgi::EGame
{
	UNKNOWN_GAME,
	GTA_III,
	GTA_VC,
	GTA_SA,
	GTA_IV,
	MANHUNT,
	BULLY,
	SOL
};